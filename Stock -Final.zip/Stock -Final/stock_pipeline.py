"""Server-side stock ML pipeline: preprocess, prediction, forecast (no GUI)."""
import json
import os
import stat
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from sklearn import preprocessing, tree
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.svm import SVR

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

REQUIRED_COLS = ["Open", "High", "Low", "Close"]


def _ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def load_and_normalize_csv(filepath: str) -> Tuple[pd.DataFrame, List[str]]:
    """Read CSV, find OHLC columns (case-insensitive), return canonical names."""
    df = pd.read_csv(filepath)
    df.columns = [c.strip() for c in df.columns]
    col_map = {c.lower(): c for c in df.columns}
    missing = []
    rename = {}
    for need in REQUIRED_COLS:
        key = need.lower()
        if key in col_map:
            rename[col_map[key]] = need
        else:
            missing.append(need)
    if missing:
        raise ValueError(f"Missing columns: {missing}. Found: {list(df.columns)}")
    df = df.rename(columns=rename)
    for c in REQUIRED_COLS:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df.dropna(subset=REQUIRED_COLS)
    return df[REQUIRED_COLS].copy(), []


def save_working_copy(df: pd.DataFrame, out_path: str) -> None:
    df[REQUIRED_COLS].to_csv(out_path, index=False)


def preprocess_dataset(filepath: str) -> Dict[str, Any]:
    df, _ = load_and_normalize_csv(filepath)
    stats = {
        "rows": int(len(df)),
        "columns": REQUIRED_COLS,
        "open_mean": float(df["Open"].mean()),
        "high_mean": float(df["High"].mean()),
        "low_mean": float(df["Low"].mean()),
        "close_mean": float(df["Close"].mean()),
        "close_min": float(df["Close"].min()),
        "close_max": float(df["Close"].max()),
    }
    preview = json.loads(df.tail(8).to_json(orient="records", date_format="iso"))
    return {"ok": True, "stats": stats, "preview": preview}


def fetch_symbol_to_csv(symbol: str, out_path: str) -> Dict[str, Any]:
    import yfinance as yf

    sym = symbol.strip().upper()
    if not sym:
        raise ValueError("Symbol is empty")
    ticker = yf.Ticker(sym)
    df = ticker.history(start="2000-01-01", auto_adjust=False)
    if df is None or df.empty:
        raise ValueError(f"No data returned for symbol '{sym}'")
    date_str = [pd.Timestamp(t).strftime("%Y-%m-%d") for t in df.index]
    out = pd.DataFrame(
        {
            "Date": date_str,
            "Open": df["Open"].values,
            "High": df["High"].values,
            "Low": df["Low"].values,
            "Close": df["Close"].values,
        }
    )
    out = out.dropna()
    tmp_path = f"{out_path}.tmp"
    try:
        out.to_csv(tmp_path)
        if os.path.exists(out_path):
            # Best effort to remove readonly flag on Windows before replace.
            try:
                os.chmod(out_path, stat.S_IWRITE | stat.S_IREAD)
            except OSError:
                pass
        os.replace(tmp_path, out_path)
    except PermissionError as e:
        try:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
        except OSError:
            pass
        raise ValueError(
            f"Cannot write '{out_path}'. Close Stock.csv in Excel/other apps and try again."
        ) from e
    except OSError as e:
        try:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
        except OSError:
            pass
        raise ValueError(f"Failed to save dataset to '{out_path}': {e}") from e
    date_from = None
    date_to = None
    if len(out) > 0 and "Date" in out.columns:
        date_from = str(out["Date"].min())
        date_to = str(out["Date"].max())
    return {
        "ok": True,
        "symbol": sym,
        "rows": len(out),
        "date_from": date_from,
        "date_to": date_to,
    }


def save_price_chart_png(csv_path: str, out_png: str, bars: int = 180) -> None:
    df = pd.read_csv(csv_path)
    df.columns = [c.strip() for c in df.columns]
    col_map = {c.lower(): c for c in df.columns}
    for need in REQUIRED_COLS:
        if need.lower() not in col_map:
            return
    for c in REQUIRED_COLS:
        df[c] = pd.to_numeric(df[col_map[c.lower()]], errors="coerce")
    df = df.dropna(subset=REQUIRED_COLS)
    if len(df) == 0:
        return
    tail = df.tail(min(bars, len(df)))
    fig, ax = plt.subplots(figsize=(10, 4), facecolor="#0f1419")
    ax.set_facecolor("#0f1419")
    x = np.arange(len(tail))
    ax.plot(x, tail["Close"].values, color="#38bdf8", linewidth=1.2, label="Close")
    ax.fill_between(x, tail["Low"].values, tail["High"].values, alpha=0.15, color="#38bdf8")
    ax.set_title("Price (recent window)", color="#e2e8f0", fontsize=11)
    ax.tick_params(colors="#94a3b8", labelsize=8)
    ax.grid(True, alpha=0.2, color="#334155")
    ax.spines[:].set_color("#334155")
    plt.tight_layout()
    plt.savefig(out_png, dpi=120, facecolor="#0f1419")
    plt.close()


def _metrics_block(y_true, y_pred) -> Dict[str, float]:
    mse = float(mean_squared_error(y_true, y_pred))
    mae = float(mean_absolute_error(y_true, y_pred))
    rmse = float(np.sqrt(mse))
    r2 = float(r2_score(y_true, y_pred))
    return {
        "mse": mse,
        "mae": mae,
        "rmse": rmse,
        "r2": r2,
    }


def run_prediction_metrics(filepath: str, title: str, out_dir: str) -> Dict[str, Any]:
    _ensure_dir(out_dir)
    df, _ = load_and_normalize_csv(filepath)
    y1 = df["Close"]
    X1 = df.drop(columns=["Close"])
    X_train, X_test, y_train, y_test = train_test_split(
        X1, y1, test_size=0.2, random_state=42
    )

    results: Dict[str, Any] = {"title": title, "algorithms": []}

    # SVR
    svr = SVR()
    svr.fit(X_train, y_train)
    y_svr = svr.predict(X_test)
    m_svr = _metrics_block(y_test, y_svr)
    m_svr["name"] = "SVM (SVR)"
    m_svr["accuracy_pct"] = float(svr.score(X_test, y_test) * 100)
    results["algorithms"].append(m_svr)

    fig, ax = plt.subplots(figsize=(8, 4), facecolor="#0f1419")
    ax.set_facecolor("#0f1419")
    x = np.arange(len(y_test))
    ax.plot(x, y_test.values, color="#94a3b8", label="Actual", linewidth=1)
    ax.plot(x, y_svr, color="#38bdf8", label="Predicted", linewidth=1)
    ax.legend(facecolor="#1e293b", edgecolor="#334155", labelcolor="#e2e8f0")
    ax.set_title(f"SVR — {title}", color="#f1f5f9", fontsize=11)
    ax.tick_params(colors="#94a3b8")
    ax.grid(True, alpha=0.2, color="#334155")
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, "pred_svr.png"), dpi=120, facecolor="#0f1419")
    plt.close()

    # Random Forest
    rf = RandomForestRegressor(random_state=42, n_estimators=100)
    rf.fit(X_train, y_train)
    y_rf = rf.predict(X_test)
    m_rf = _metrics_block(y_test, y_rf)
    m_rf["name"] = "Random Forest"
    m_rf["accuracy_pct"] = float(rf.score(X_test, y_test) * 100)
    results["algorithms"].append(m_rf)

    fig, ax = plt.subplots(figsize=(8, 4), facecolor="#0f1419")
    ax.set_facecolor("#0f1419")
    ax.plot(x, y_test.values, color="#94a3b8", label="Actual", linewidth=1)
    ax.plot(x, y_rf, color="#a78bfa", label="Predicted", linewidth=1)
    ax.legend(facecolor="#1e293b", edgecolor="#334155", labelcolor="#e2e8f0")
    ax.set_title(f"Random Forest — {title}", color="#f1f5f9", fontsize=11)
    ax.tick_params(colors="#94a3b8")
    ax.grid(True, alpha=0.2, color="#334155")
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, "pred_rf.png"), dpi=120, facecolor="#0f1419")
    plt.close()

    # Comparison bar chart (MSE)
    names = [a["name"] for a in results["algorithms"]]
    mses = [a["mse"] for a in results["algorithms"]]
    fig, ax = plt.subplots(figsize=(6, 3.5), facecolor="#0f1419")
    ax.set_facecolor("#0f1419")
    ax.bar(names, mses, color=["#38bdf8", "#a78bfa"], alpha=0.85)
    ax.set_ylabel("MSE", color="#94a3b8")
    ax.set_title("MSE comparison", color="#f1f5f9", fontsize=11)
    ax.tick_params(colors="#94a3b8")
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, "pred_mse_bar.png"), dpi=120, facecolor="#0f1419")
    plt.close()

    return results


def _forecast_ohlc_from_predicted_closes(
    closes: np.ndarray,
    d: pd.DataFrame,
    forecast_start_date: Optional[str],
) -> List[Dict[str, Any]]:
    """Build per-day OHLC rows from model-predicted closes.

    Open chains from the last historical close; High/Low use a typical daily
    range estimated from recent bars (model only predicts Close).
    """
    last_close = float(d["Close"].iloc[-1])
    tail = d.tail(min(60, len(d)))
    hl_mean = float((tail["High"] - tail["Low"]).mean())
    if not np.isfinite(hl_mean) or hl_mean <= 0:
        hl_mean = max(1e-6, 0.015 * last_close)

    rows: List[Dict[str, Any]] = []
    prev = last_close
    for i, c in enumerate(closes):
        c = float(c)
        o = prev
        spread = 0.45 * hl_mean
        hi = max(o, c) + spread
        lo = min(o, c) - spread
        if lo < 1e-9:
            lo = 1e-9
        row: Dict[str, Any] = {
            "day": i + 1,
            "open": o,
            "high": hi,
            "low": lo,
            "close": c,
        }
        if forecast_start_date:
            t0 = pd.Timestamp(forecast_start_date)
            row["date"] = (t0 + pd.Timedelta(days=i)).strftime("%Y-%m-%d")
        rows.append(row)
        prev = c
    return rows


def run_forecast_metrics(filepath: str, out_dir: str, forecast_out: int = 5) -> Dict[str, Any]:
    _ensure_dir(out_dir)
    df = pd.read_csv(filepath)
    df.columns = [c.strip() for c in df.columns]
    col_map = {c.lower(): c for c in df.columns}
    for need in REQUIRED_COLS:
        if need.lower() not in col_map:
            raise ValueError(f"Forecast needs columns {REQUIRED_COLS}")
    d = pd.DataFrame()
    for c in REQUIRED_COLS:
        d[c] = pd.to_numeric(df[col_map[c.lower()]], errors="coerce")

    # Try to detect a date column to report dataset and forecast ranges.
    date_col = None
    for cand in ("date", "datetime", "timestamp", "unnamed: 0"):
        if cand in col_map:
            date_col = col_map[cand]
            break
    date_series = None
    if date_col is not None:
        date_series = pd.to_datetime(df[date_col], errors="coerce")

    d = d.dropna()
    d["HL_PCT"] = (d["High"] - d["Close"]) / d["Close"] * 100.0
    d["PCT_Change"] = (d["Close"] - d["Open"]) / d["Open"] * 100.0
    d["label"] = d["Close"].shift(-forecast_out)
    d = d.dropna()
    feat = d[["Close", "HL_PCT", "PCT_Change"]].values
    y = d["label"].values
    X = preprocessing.StandardScaler().fit_transform(feat)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    X_lately = X[-forecast_out:]

    forecast_date_from = None
    forecast_date_to = None
    dataset_date_from = None
    dataset_date_to = None
    if date_series is not None:
        ds = date_series.dropna()
        if len(ds) > 0:
            dataset_date_from = ds.min().strftime("%Y-%m-%d")
            dataset_date_to = ds.max().strftime("%Y-%m-%d")
            forecast_start = ds.max() + pd.Timedelta(days=1)
            forecast_end = forecast_start + pd.Timedelta(days=forecast_out - 1)
            forecast_date_from = forecast_start.strftime("%Y-%m-%d")
            forecast_date_to = forecast_end.strftime("%Y-%m-%d")

    out: Dict[str, Any] = {
        "horizon_days": forecast_out,
        "algorithms": [],
        "predicted_prices": {},
        "dataset_date_from": dataset_date_from,
        "dataset_date_to": dataset_date_to,
        "forecast_date_from": forecast_date_from,
        "forecast_date_to": forecast_date_to,
    }

    dt = tree.DecisionTreeRegressor(random_state=42)
    dt.fit(X_train, y_train)
    pred_dt = dt.predict(X_lately)
    m_dt = {
        "name": "Decision Tree",
        "mse": float(mean_squared_error(y_test, dt.predict(X_test))),
        "mae": float(mean_absolute_error(y_test, dt.predict(X_test))),
        "rmse": float(np.sqrt(mean_squared_error(y_test, dt.predict(X_test)))),
        "r2": float(r2_score(y_test, dt.predict(X_test))),
        "accuracy_pct": float(dt.score(X_test, y_test) * 100),
    }
    out["algorithms"].append(m_dt)
    out["predicted_prices"]["decision_tree"] = [float(x) for x in pred_dt]

    rf = RandomForestRegressor(random_state=42, n_estimators=100)
    rf.fit(X_train, y_train)
    pred_rf = rf.predict(X_lately)
    m_rf = {
        "name": "Random Forest",
        "mse": float(mean_squared_error(y_test, rf.predict(X_test))),
        "mae": float(mean_absolute_error(y_test, rf.predict(X_test))),
        "rmse": float(np.sqrt(mean_squared_error(y_test, rf.predict(X_test)))),
        "r2": float(r2_score(y_test, rf.predict(X_test))),
        "accuracy_pct": float(rf.score(X_test, y_test) * 100),
    }
    out["algorithms"].append(m_rf)
    out["predicted_prices"]["random_forest"] = [float(x) for x in pred_rf]

    out["forecast_ohlc"] = {
        "decision_tree": _forecast_ohlc_from_predicted_closes(
            pred_dt, d, forecast_date_from
        ),
        "random_forest": _forecast_ohlc_from_predicted_closes(
            pred_rf, d, forecast_date_from
        ),
    }

    fig, ax = plt.subplots(figsize=(8, 4), facecolor="#0f1419")
    ax.set_facecolor("#0f1419")
    days = np.arange(forecast_out)
    ax.plot(days, pred_dt, color="#fbbf24", marker="o", label="Decision Tree")
    ax.plot(days, pred_rf, color="#34d399", marker="o", label="Random Forest")
    ax.legend(facecolor="#1e293b", edgecolor="#334155", labelcolor="#e2e8f0")
    ax.set_xlabel("Day ahead", color="#94a3b8")
    ax.set_ylabel("Predicted close", color="#94a3b8")
    ax.set_title(f"{forecast_out}-day forecast", color="#f1f5f9", fontsize=11)
    ax.tick_params(colors="#94a3b8")
    ax.grid(True, alpha=0.2, color="#334155")
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, "forecast_compare.png"), dpi=120, facecolor="#0f1419")
    plt.close()

    return out
