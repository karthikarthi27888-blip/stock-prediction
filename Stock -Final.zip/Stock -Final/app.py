import os
import time
from flask import Flask, jsonify, render_template, request

from stock_pipeline import (
    fetch_symbol_to_csv,
    preprocess_dataset,
    run_forecast_metrics,
    run_prediction_metrics,
    save_working_copy,
    load_and_normalize_csv,
    save_price_chart_png,
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")
OUTPUT_FOLDER = os.path.join(BASE_DIR, "static", "outputs")
WORKING_CSV = os.path.join(BASE_DIR, "Stock.csv")

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 32 * 1024 * 1024


def _working_csv_exists() -> bool:
    return os.path.isfile(WORKING_CSV)


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/upload", methods=["POST"])
def api_upload():
    if "file" not in request.files:
        return jsonify({"ok": False, "error": "No file field 'file'"}), 400
    f = request.files["file"]
    if not f.filename:
        return jsonify({"ok": False, "error": "No file selected"}), 400
    if not f.filename.lower().endswith(".csv"):
        return jsonify({"ok": False, "error": "Please upload a .csv file"}), 400
    path = os.path.join(UPLOAD_FOLDER, "uploaded.csv")
    f.save(path)
    try:
        df, _ = load_and_normalize_csv(path)
        save_working_copy(df, WORKING_CSV)
    except ValueError as e:
        return jsonify({"ok": False, "error": str(e)}), 400
    chart = os.path.join(OUTPUT_FOLDER, "price_chart.png")
    save_price_chart_png(WORKING_CSV, chart)
    return jsonify(
        {
            "ok": True,
            "message": f"Loaded {len(df)} rows with OHLC columns.",
            "rows": len(df),
            "chart": "/static/outputs/price_chart.png?v=" + str(int(time.time())),
        }
    )


@app.route("/api/fetch_symbol", methods=["POST"])
def api_fetch_symbol():
    data = request.get_json(silent=True) or {}
    symbol = (data.get("symbol") or "").strip()
    if not symbol:
        return jsonify({"ok": False, "error": "Enter a symbol (e.g. AAPL, SBIN.NS)"}), 400
    try:
        info = fetch_symbol_to_csv(symbol, WORKING_CSV)
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 400
    chart = os.path.join(OUTPUT_FOLDER, "price_chart.png")
    save_price_chart_png(WORKING_CSV, chart)
    info["chart"] = "/static/outputs/price_chart.png?v=" + str(int(time.time()))
    return jsonify(info)


@app.route("/api/preprocess", methods=["POST"])
def api_preprocess():
    if not _working_csv_exists():
        return jsonify(
            {"ok": False, "error": "No dataset. Load a symbol first."}
        ), 400
    try:
        out = preprocess_dataset(WORKING_CSV)
    except ValueError as e:
        return jsonify({"ok": False, "error": str(e)}), 400
    out["chart"] = "/static/outputs/price_chart.png?v=" + str(int(time.time()))
    return jsonify(out)


@app.route("/api/predict", methods=["POST"])
def api_predict():
    if not _working_csv_exists():
        return jsonify(
            {"ok": False, "error": "No dataset. Load a symbol first."}
        ), 400
    data = request.get_json(silent=True) or {}
    title = (data.get("title") or "Stock").strip() or "Stock"
    try:
        result = run_prediction_metrics(WORKING_CSV, title, OUTPUT_FOLDER)
    except ValueError as e:
        return jsonify({"ok": False, "error": str(e)}), 400
    v = str(int(time.time()))
    result["ok"] = True
    result["images"] = {
        "svr": f"/static/outputs/pred_svr.png?v={v}",
        "rf": f"/static/outputs/pred_rf.png?v={v}",
        "mse_bar": f"/static/outputs/pred_mse_bar.png?v={v}",
    }
    return jsonify(result)


@app.route("/api/forecast", methods=["POST"])
def api_forecast():
    if not _working_csv_exists():
        return jsonify(
            {"ok": False, "error": "No dataset. Load a symbol first."}
        ), 400
    try:
        result = run_forecast_metrics(WORKING_CSV, OUTPUT_FOLDER)
    except ValueError as e:
        return jsonify({"ok": False, "error": str(e)}), 400
    v = str(int(time.time()))
    result["ok"] = True
    result["images"] = {"forecast": f"/static/outputs/forecast_compare.png?v={v}"}
    return jsonify(result)


@app.route("/api/status", methods=["GET"])
def api_status():
    return jsonify(
        {
            "has_data": _working_csv_exists(),
            "working_path": "Stock.csv" if _working_csv_exists() else None,
        }
    )


@app.route("/api/refresh_chart", methods=["GET"])
def api_refresh_chart():
    if not _working_csv_exists():
        return jsonify({"ok": False}), 404
    chart = os.path.join(OUTPUT_FOLDER, "price_chart.png")
    save_price_chart_png(WORKING_CSV, chart)
    return jsonify(
        {
            "ok": True,
            "chart": "/static/outputs/price_chart.png?v=" + str(int(time.time())),
        }
    )


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
